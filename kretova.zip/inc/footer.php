<script src="https://ajax.googleapis.com/ajax/libs/jquery.min.js"></script>
<script src="public/js/bootstrap.js"></script>
