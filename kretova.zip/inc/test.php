<html>
<head >
    <title>название отображенное при поиске</title>
    <link rel="stylesheet" href="./css/test.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">
</head>
<body>
<div class="totalContainers">
    <div class ="navigation">

            <div class="container">
                <div class="header" >название шапка сайта</div>
                <div class="sidebar">
                    <p><a href="#">Главная</a></p>
                    <p><a href="#">о нас</a></p>
                    <p><a href="#">Вопросы</a></p>
                </div>
                <div class ="navigation">
                    <div class="totalContainers">
                        <div class="content">
                            <h2>заголовок текста</h2>

                            <p>
                        Необычно холодная весна нынешнего года была неблагоприятной для пчел, даже, можно сказать,
                                опасной. Весной колонии пчел, чтобы вырастить полноценное, работоспособное потомство, нужно много пыльцы и меда. К сожалению, холодная погода стояла в апреле, заморозки испортили и начало мая. А значит, все это неизбежно скажется и на ценах. «МК-Эстония» разбиралась в проблемах местных пчеловодов.</p>
                            </p>

                        </div>
                    </div>
                </div>

        </div>
    </div>
</div>
</body>
</html>

