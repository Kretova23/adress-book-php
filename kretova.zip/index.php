<?php
require_once('inc/header.php');
require_once('./inc/function.php');


$link = connectDb();// connect to DB



 $contacts = getAllContacts($link);
//dd($row);

//foreach ($contacts as $contact){
//echo 'name='.$contact['name'] .'<br>';
//}
 $contact = getContactById($link,1);
echo $contact->name;
//dd($contact);


echo $contact['City'];

?>
<?php
$posts = get_posts();

?>


<div class="container">
    <div class="row">
     <div class="row">
         <div class="col-md-9">
             <div class="page-header">
                 <h1> Все записи</h1>
             </div>
            <!-- <?php
            /* $posts = get_posts();
             ?>
             <?php foreach ($posts as $post): */?>-->
      <div class="row">
          <div class="col-md-3">
       <a href="#" class="thumbnail">
        <img src="http://placehold.it/260x180" alt=""><!--<?/*=$post('image')*/?>-->
       </a>
      </div>
      <div class="cold-md-9">
          <h4><a href="#"><!--<?/*=$post('title')*/?>--></a></h4>
          <p>
<?=$post('City')?>
          </p>
            <p><a class="btn btn-info btn-sm" href="#">Подробнее</a></p>
          <br/>
          <ul class="list-inline">
              <li>
                  <span class="glyphicon glyphicon-list"></span> <a href="#">Название категории</a> | </li>
              <li> <span class="glyphicon glyphicon-calendar"></span>  19 января 2020 21:00</li>
          </ul>
     </div>
      </div>
<hr>
            <!-- <?php /*endforeach;*/?>-->
</div>
<div class="col-md-3" >
    sidebar
</div>
     </div>
    </div>
-->





